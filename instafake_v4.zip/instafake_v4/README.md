# mean_flickr
A mean framework implementation of uploading photos &amp; liking them
